<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/',"customeController@display");


Route::get("/login","customeController@index");
Route::get("/registration","customeController@welcome");
Route::post("/registr","customeController@registration");


Route::post("/delete","customeController@deleteData");


Route::get("/login","customeController@loginpPage");
Route::post("/loginData","customeController@loginData");

Route::get("/success",function(){
    return view("success");
});