<!DOCTYPE html>
<html>
<head>
    <title>Custom Auth in Laravel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta3/dist/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.6.0/jquery.min.js" integrity="sha512-894YE6QWD5I59HgZOGReFYm4dnWc1Qt5NtvYSaNcOP+u1T9qYdvdihz0PPSiiqn/+/3e7Jo4EaG7TubfWGUrMQ==" crossorigin="anonymous" referrerpolicy="no-referrer"></script>

    <?php echo $__env->yieldContent("custome-js"); ?>
</head>

<body token="<?php echo e(csrf_token()); ?>">

  
    <?php echo $__env->yieldContent('content'); ?>

</body>

</html><?php /**PATH D:\laravel project\AaraTech\resources\views/dashboard.blade.php ENDPATH**/ ?>