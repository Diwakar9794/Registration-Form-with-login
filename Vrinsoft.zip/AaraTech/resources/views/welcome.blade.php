@extends('dashboard')

@section('custome-js')
    <script src="../js/index.js?catch=<?php echo time(); ?>"></script>
@endsection

@section('content')
<main class="signup-form">
    <div class="cotainer">
        <div class="row justify-content-center">

            <div class="col-md-8">
                <a href="{{url('registration')}}" class="btn btn-primary">Registration + </a>
                <a href="{{url('login')}}" class="btn btn-success">Login + </a>

                <span class="msg"></span>
                <table class="table ">
                    <th>
                        <td>ID</td>
                        <td>Name</td>
                        <td>Email</td>
                        <td>Contact</td>
                        <td>Address</td>
                    </th>
                    @foreach($result as $value)
                        <tr>
                            <td>{{ $value->id }}</td>
                            <td>{{ $value->name }}</td>
                            <td>{{ $value->email }}</td>
                            <td>{{ $value->contact }}</td>
                            <td>{{ $value->address }}</td>
                            <td><button value="{{ $value->id }}" class="btn btn-danger delete">Delete</button></td>
                        </tr>
                    @endforeach
                </table>
            </div>
        </div>
    </div>
</main>
@endsection